/**
 * NICOLAI STORE - JAVASCRIPT PRINCIPAL
 * Manejo del modal de productos y funcionalidades interactivas
 */

// ========== VARIABLES GLOBALES DEL CARRUSEL ==========
let currentSlide = 0;
let slideInterval;
const slideDelay = 5000; // 5 segundos entre slides

// ========== FUNCIONES DEL CARRUSEL ==========

/**
 * Inicializa el carrusel de banners
 */
function initBannerSlider() {
  const slides = document.querySelectorAll('.banner-slide');
  const indicatorsContainer = document.getElementById('bannerIndicators');
  
  // Crear indicadores dinámicamente
  slides.forEach((_, index) => {
    const dot = document.createElement('div');
    dot.className = `banner-dot ${index === 0 ? 'active' : ''}`;
    dot.onclick = () => goToSlide(index);
    indicatorsContainer.appendChild(dot);
  });
  
  // Iniciar auto-play
  startAutoPlay();
  
  console.log(`Carrusel inicializado con ${slides.length} slides ✅`);
}

/**
 * Muestra un slide específico
 * @param {number} index - Índice del slide a mostrar
 */
function showSlide(index) {
  const slides = document.querySelectorAll('.banner-slide');
  const dots = document.querySelectorAll('.banner-dot');
  
  // Validar índice
  if (index >= slides.length) {
    currentSlide = 0;
  } else if (index < 0) {
    currentSlide = slides.length - 1;
  } else {
    currentSlide = index;
  }
  
  // Ocultar todos los slides
  slides.forEach(slide => slide.classList.remove('active'));
  dots.forEach(dot => dot.classList.remove('active'));
  
  // Mostrar slide actual
  slides[currentSlide].classList.add('active');
  dots[currentSlide].classList.add('active');
}

/**
 * Avanza al siguiente slide
 */
function nextSlide() {
  showSlide(currentSlide + 1);
  resetAutoPlay();
}

/**
 * Retrocede al slide anterior
 */
function prevSlide() {
  showSlide(currentSlide - 1);
  resetAutoPlay();
}

/**
 * Va a un slide específico
 * @param {number} index - Índice del slide
 */
function goToSlide(index) {
  showSlide(index);
  resetAutoPlay();
}

/**
 * Inicia el auto-play del carrusel
 */
function startAutoPlay() {
  slideInterval = setInterval(() => {
    nextSlide();
  }, slideDelay);
}

/**
 * Detiene el auto-play
 */
function stopAutoPlay() {
  clearInterval(slideInterval);
}

/**
 * Reinicia el auto-play
 */
function resetAutoPlay() {
  stopAutoPlay();
  startAutoPlay();
}

// ========== FUNCIONES DEL MODAL ==========

/**
 * Abre el modal con la información del producto
 * @param {HTMLElement} btn - Botón que disparó el evento
 */
function openModal(btn) {
  const card = btn.closest('.card');
  const title = card.querySelector('h3').innerText;
  const price = card.querySelector('.price').innerText;
  const mainImg = card.querySelector('img').src;

  // Obtener imágenes adicionales del data-attribute (miniaturas)
  const thumbnails = card.dataset.thumbnails ? card.dataset.thumbnails.split(',') : [];
  
  // Siempre incluir la imagen principal como primera miniatura
  const allImages = [mainImg, ...thumbnails];

  // Mostrar modal
  document.getElementById('modal').style.display = 'flex';
  
  // Actualizar información
  document.getElementById('modalTitle').innerText = title;
  document.getElementById('priceBig').innerText = price;
  document.getElementById('mainImg').src = mainImg;
  
  // Actualizar miniaturas dinámicamente
  const thumbsContainer = document.getElementById('thumbsContainer');
  thumbsContainer.innerHTML = ''; // Limpiar miniaturas existentes
  
  allImages.forEach((imgSrc, index) => {
    const thumb = document.createElement('img');
    thumb.src = imgSrc.trim();
    thumb.alt = `Vista ${index + 1}`;
    thumb.className = index === 0 ? 'active' : '';
    thumb.onclick = function() { setImg(this); };
    thumbsContainer.appendChild(thumb);
  });
  
  // Prevenir scroll del body
  document.body.style.overflow = 'hidden';
  
  // Pausar carrusel cuando el modal está abierto
  stopAutoPlay();
}

/**
 * Cierra el modal
 */
function closeModal() {
  document.getElementById('modal').style.display = 'none';
  document.body.style.overflow = 'auto';
  
  // Reanudar carrusel
  startAutoPlay();
}

/**
 * Cierra el modal al hacer clic fuera de él
 * @param {Event} event - Evento del clic
 */
function closeModalOnOutside(event) {
  if (event.target.id === 'modal') {
    closeModal();
  }
}

/**
 * Cambia la imagen principal del modal
 * @param {HTMLElement} imgElement - Elemento de imagen clickeado
 */
function setImg(imgElement) {
  // Cambiar imagen principal
  document.getElementById('mainImg').src = imgElement.src;
  
  // Actualizar clase active en miniaturas
  const thumbs = document.querySelectorAll('.thumbs img');
  thumbs.forEach(thumb => thumb.classList.remove('active'));
  imgElement.classList.add('active');
}

// ========== EVENT LISTENERS ==========

/**
 * Inicialización al cargar el DOM
 */
document.addEventListener('DOMContentLoaded', function() {
  console.log('Nicolai Store cargado correctamente ✅');
  
  // Inicializar carrusel de banners
  initBannerSlider();
  
  // Pausar carrusel cuando el usuario está en otra pestaña
  document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
      stopAutoPlay();
    } else {
      startAutoPlay();
    }
  });
  
  // Cerrar modal con tecla ESC
  document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
      const modal = document.getElementById('modal');
      if (modal.style.display === 'flex') {
        closeModal();
      }
    }
  });
  
  // Scroll suave para enlaces internos
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
});

// ========== FUNCIONES AUXILIARES ==========

/**
 * Actualiza la fecha de última actualización
 */
function updateDate() {
  const dateElement = document.querySelector('.updated');
  if (dateElement) {
    const today = new Date();
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const formattedDate = today.toLocaleDateString('es-ES', options);
    dateElement.innerHTML = `⏱ Última actualización: ${formattedDate}`;
  }
}

// Llamar a la función al cargar
document.addEventListener('DOMContentLoaded', updateDate);


