# 🎮 Nicolai Store - Catálogo de Figuras de Anime

Sitio web para catálogo de figuras de anime con diseño moderno, responsive y sistema dinámico de gestión de productos.

---

## ✨ CARACTERÍSTICAS PRINCIPALES

- ✅ **Sistema Dinámico de Miniaturas**: Cada producto puede tener sus propias imágenes adicionales
- ✅ **Carrusel de Banners Automático**: Auto-play cada 5 segundos con controles manuales
- ✅ **Diseño Responsive**: Se adapta a móviles, tablets y desktop
- ✅ **Grid de 3 Columnas**: Catálogo organizado (3 en desktop, 2 en tablet, 1 en móvil)
- ✅ **Modal Mejorado**: Popup profesional con galería de imágenes dinámica
- ✅ **Logo Animado**: Con banderas japonesas animadas y favicon personalizado
- ✅ **Optimizado para Mantenimiento**: Fácil agregar/quitar productos
- ✅ **Integración WhatsApp**: Botón directo de consulta
- ✅ **Animaciones Suaves**: Transiciones y efectos visuales atractivos
- ✅ **SEO Friendly**: Meta tags optimizados
- ✅ **Accesibilidad**: Atributos ARIA y buenas prácticas

---

## 📁 ESTRUCTURA DEL PROYECTO

```
nicolai-store/
├── index.html              # Página principal
├── css/
│   ├── styles.css          # Estilos principales
│   └── README.md           # Guía de personalización CSS
├── js/
│   ├── main.js             # Funcionalidades JavaScript
│   └── README.md           # Guía de funcionalidades JS
├── images/                 # Imágenes del sitio
│   ├── logo.png            # Logo principal (header)
│   ├── logo-small.png      # Favicon (pestaña navegador)
│   ├── banner-1.jpg        # Banners del carrusel
│   ├── banner-2.jpg
│   ├── banner-3.jpg
│   ├── [productos].jpg     # Imágenes de productos
│   └── README.md           # Guía de imágenes
├── README.md               # Este archivo
└── DEPLOY.md               # Guía de despliegue en Vercel
```

---

## 🚀 INICIO RÁPIDO

### 1. Preparar Imágenes

Coloca en la carpeta `images/`:
- `logo.png` (200x200px, fondo transparente)
- `logo-small.png` (64x64px para favicon)
- `banner-1.jpg`, `banner-2.jpg`, `banner-3.jpg` (1200x380px)
- Imágenes de tus productos

### 2. Agregar Productos

Edita `index.html`, busca la sección del catálogo y agrega:

```html
<div class="card" data-thumbnails="images/producto-vista2.jpg, images/producto-caja.jpg">
  <div class="card-image">
    <img src="images/tu-producto.jpg" alt="Descripción">
  </div>
  <div class="card-body">
    <h3>Nombre del Producto</h3>
    <div class="price">S/ 450</div>
    <div class="stock">🟧 Stock: 1 unidad disponible</div>
    <div class="btn-group">
      <button class="btn btn-desc" onclick="openModal(this)">Ver descripción</button>
    </div>
  </div>
</div>
```

**IMPORTANTE:** El atributo `data-thumbnails` permite agregar imágenes adicionales:
- Separa las rutas con comas
- La imagen principal siempre será la primera miniatura
- Si no tienes miniaturas adicionales, omite el atributo

### 3. Personalizar

- **Número de WhatsApp:** Busca `51999999999` en `index.html` y reemplázalo
- **Redes Sociales:** Actualiza los enlaces en la sección `<div class="socials">`
- **Colores:** Revisa `css/README.md` para cambiar la paleta
- **Logo:** Reemplaza `logo.png` y `logo-small.png` en `/images`

---

## 📚 GUÍAS DETALLADAS

### 🎨 Personalización Visual
Lee: [`css/README.md`](css/README.md)
- Cambiar colores del tema
- Ajustar tamaño del logo
- Modificar animaciones del carrusel
- Tamaño de miniaturas
- Número de columnas

### ⚙️ Funcionalidades
Lee: [`js/README.md`](js/README.md)
- Velocidad del carrusel
- Desactivar auto-play
- Formato de fecha
- Sistema de miniaturas dinámico
- Debugging

### 📸 Gestión de Imágenes
Lee: [`images/README.md`](images/README.md)
- Especificaciones técnicas
- Crear favicon desde logo
- Convenciones de nombres
- Herramientas de optimización

### 🚀 Despliegue y Actualización
Lee: [`DEPLOY.md`](DEPLOY.md)
- Configuración inicial de Git
- Subir a GitHub
- Desplegar en Vercel
- **Flujo semanal de actualización de productos**
- Comandos útiles
- Solución de problemas

---

## 🎯 SISTEMA DINÁMICO DE MINIATURAS

### Cómo Funciona

Cada producto puede tener múltiples imágenes para mostrar en el modal:

```html
<!-- Producto con 3 imágenes adicionales -->
<div class="card" data-thumbnails="images/goku-lateral.jpg, images/goku-trasera.jpg, images/goku-caja.jpg">
  <div class="card-image">
    <img src="images/goku-frontal.jpg" alt="Goku">
  </div>
  <!-- ... resto del producto ... -->
</div>
```

**Al hacer clic en "Ver descripción":**
1. Se abre el modal
2. Se cargan automáticamente 4 miniaturas:
   - `goku-frontal.jpg` (imagen principal)
   - `goku-lateral.jpg`
   - `goku-trasera.jpg`
   - `goku-caja.jpg`
3. Click en cualquier miniatura cambia la imagen principal

---

## 🎨 COLORES DEL TEMA

- **Naranja Principal**: `#ff8a00`
- **Naranja Degradado**: `#e67600`
- **Fondo Oscuro**: `#0e0e11`
- **Tarjetas**: `#1a1a1f`

Para cambiarlos, ver [`css/README.md`](css/README.md)

---

## ⚡ MODIFICACIONES RÁPIDAS

### Cambiar Velocidad del Carrusel

**Archivo:** `js/main.js` (línea 8)
```javascript
const slideDelay = 5000; // Cambiar valor en milisegundos
```

### Cambiar Animación del Carrusel

**Archivo:** `css/styles.css` (línea ~150)
```css
.banner-slide {
  transition: opacity 1s ease-in-out; /* Cambiar duración y tipo */
}
```

Ver todas las opciones en [`css/README.md`](css/README.md)

### Agregar Más Banners

1. Coloca `banner-4.jpg` en `/images`
2. En `index.html`, agrega dentro de `<div class="banner-slides">`:

```html
<div class="banner-slide">
  <img src="images/banner-4.jpg" alt="Nuevo banner">
  <div class="banner-overlay">
    <div class="banner-text">Tu título</div>
    <div class="banner-subtext">Tu subtítulo</div>
  </div>
</div>
```

---

## 🌐 DESPLEGAR EN VERCEL (GRATIS)

### Método Rápido

1. Sube tu código a GitHub
2. Ve a [vercel.com](https://vercel.com)
3. Conecta tu repositorio
4. Haz clic en "Deploy"

**Guía completa:** [`DEPLOY.md`](DEPLOY.md)

### Dominio Personalizado

Tu sitio estará en: `https://tu-proyecto.vercel.app`

Para usar tu propio dominio: Ver sección "Configurar Dominio" en [`DEPLOY.md`](DEPLOY.md)

---

## 🔄 FLUJO DE ACTUALIZACIÓN SEMANAL

1. **Preparar imágenes** (optimizar con TinyPNG)
2. **Editar `index.html`** (agregar/quitar productos)
3. **Probar localmente** (abrir index.html)
4. **Subir cambios:**
   ```bash
   git add .
   git commit -m "Actualización semanal: productos nuevos"
   git push
   ```
5. **Vercel actualiza automáticamente** en 30 segundos ✨

**Guía detallada:** [`DEPLOY.md`](DEPLOY.md)

---

## 📱 RESPONSIVE BREAKPOINTS

- **Desktop**: > 1024px (3 columnas)
- **Tablet**: 640px - 1024px (2 columnas)
- **Móvil**: < 640px (1 columna)

---

## 🛠️ TECNOLOGÍAS UTILIZADAS

- HTML5
- CSS3 (Grid, Flexbox, Animaciones, Transiciones)
- JavaScript Vanilla (ES6+)
- Font Awesome Icons 6.5.1
- Google Fonts (Poppins)

---

## 🐛 SOLUCIÓN DE PROBLEMAS

### Las imágenes no cargan
- Verifica que las rutas sean correctas
- Revisa que los nombres de archivo coincidan (mayúsculas/minúsculas)
- Asegúrate de que las imágenes estén en `/images`

### El carrusel no funciona
- Abre F12 > Console para ver errores
- Verifica que los banners existan en `/images`
- Revisa que `js/main.js` esté cargando correctamente

### El modal no muestra miniaturas
- Verifica el atributo `data-thumbnails` en el HTML
- Asegúrate de que las rutas de imágenes sean correctas
- Las rutas deben estar separadas por comas

### Los cambios no se ven en Vercel
- Espera 30-60 segundos después del push
- Limpia la caché del navegador (Ctrl+Shift+R)
- Revisa el dashboard de Vercel para ver errores

**Más ayuda:** [`DEPLOY.md`](DEPLOY.md) sección "Solución de Problemas"

---

## 📄 LICENCIA

Este proyecto es de uso personal para Nicolai Store.

---

## 👨‍💻 CRÉDITOS

**Nicolai Store**
- Facebook: [@nicolaistore](https://facebook.com/nicolaistore)
- Instagram: [@nicolaistore](https://instagram.com/nicolaistore)
- TikTok: [@nicolaistore](https://tiktok.com/@nicolaistore)

**Desarrollado por:** [Tu Nombre]

---

## 🎯 PRÓXIMOS PASOS

1. ✅ Lee [`DEPLOY.md`](DEPLOY.md) para subir tu sitio
2. ✅ Personaliza el logo y colores
3. ✅ Agrega tus productos
4. ✅ Comparte en redes sociales
5. ✅ Mantén el catálogo actualizado semanalmente

---

¡Gracias por usar Nicolai Store! 🎌✨

